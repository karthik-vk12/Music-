package com.devxrohan.smusic.viewmodels

import android.content.Context
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.devxrohan.smusic.innertube.YouTube
import com.devxrohan.smusic.innertube.models.AlbumItem
import com.devxrohan.smusic.innertube.models.filterExplicit
import com.devxrohan.smusic.constants.HideExplicitKey
import com.devxrohan.smusic.constants.LastNewReleaseCheckKey
import com.devxrohan.smusic.db.MusicDatabase
import com.devxrohan.smusic.utils.dataStore
import com.devxrohan.smusic.utils.getSuspend
import com.devxrohan.smusic.utils.get
import com.devxrohan.smusic.utils.reportException
import dagger.hilt.android.lifecycle.HiltViewModel
import dagger.hilt.android.qualifiers.ApplicationContext
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.launch
import javax.inject.Inject

enum class AlbumReleaseType {
    ALBUM, SINGLE, EP
}

val AlbumItem.releaseType: AlbumReleaseType
    get() {
        val titleLower = title.lowercase()
        return when {
            titleLower.contains("single") -> AlbumReleaseType.SINGLE
            titleLower.contains("ep") -> AlbumReleaseType.EP
            else -> AlbumReleaseType.ALBUM
        }
    }

sealed interface NewReleaseUiState {
    data object Loading : NewReleaseUiState
    data class Success(val albums: List<AlbumItem>) : NewReleaseUiState
    data object Empty : NewReleaseUiState
    data class Error(val throwable: Throwable?) : NewReleaseUiState
}

@HiltViewModel
class NewReleaseViewModel
@Inject
constructor(
    @ApplicationContext val context: Context,
    private val database: MusicDatabase,
) : ViewModel() {
    private val _newReleaseAlbums = MutableStateFlow<List<AlbumItem>>(emptyList())
    val newReleaseAlbums = _newReleaseAlbums.asStateFlow()

    private val _uiState = MutableStateFlow<NewReleaseUiState>(NewReleaseUiState.Loading)
    val uiState = _uiState.asStateFlow()

    private val _hasNewReleases = MutableStateFlow(false)
    val hasNewReleases = _hasNewReleases.asStateFlow()

    val albums = _newReleaseAlbums.map { list ->
        val filtered = list.filter { it.releaseType == AlbumReleaseType.ALBUM }
        if (filtered.isNotEmpty()) filtered else list
    }
    val singles = _newReleaseAlbums.map { list ->
        val filtered = list.filter { it.releaseType == AlbumReleaseType.SINGLE }
        if (filtered.isNotEmpty()) filtered else list.drop(2)
    }
    val eps = _newReleaseAlbums.map { list ->
        val filtered = list.filter { it.releaseType == AlbumReleaseType.EP }
        if (filtered.isNotEmpty()) filtered else list.drop(4)
    }

    init {
        load()
    }

    fun retry() {
        load()
    }

    private fun load() {
        viewModelScope.launch(Dispatchers.IO) {
            _uiState.value = NewReleaseUiState.Loading
            try {
                val albums = YouTube.newReleaseAlbums().getOrThrow()
                val artists: MutableMap<Int, String> = mutableMapOf()
                val favouriteArtists: MutableMap<Int, String> = mutableMapOf()
                database.allArtistsByPlayTime().first().let { list ->
                    var favIndex = 0
                    for ((artistsIndex, artist) in list.withIndex()) {
                        artists[artistsIndex] = artist.id
                        if (artist.artist.bookmarkedAt != null) {
                            favouriteArtists[favIndex] = artist.id
                            favIndex++
                        }
                    }
                }

                val sortedAlbums = albums
                    .sortedBy { album ->
                        val artistIds = album.artists.orEmpty().mapNotNull { it.id }
                        val firstArtistKey =
                            artistIds.firstNotNullOfOrNull { artistId ->
                                if (artistId in favouriteArtists.values) {
                                    favouriteArtists.entries.firstOrNull { it.value == artistId }?.key
                                } else {
                                    artists.entries.firstOrNull { it.value == artistId }?.key
                                }
                            } ?: Int.MAX_VALUE
                        firstArtistKey
                    }.filterExplicit(context.dataStore.getSuspend(HideExplicitKey, false))

                _newReleaseAlbums.value = sortedAlbums
                _uiState.value =
                    if (sortedAlbums.isEmpty()) NewReleaseUiState.Empty
                    else NewReleaseUiState.Success(sortedAlbums)

                checkForNewReleases()
            } catch (t: Throwable) {
                reportException(t)
                _uiState.value = NewReleaseUiState.Error(t)
            }
        }
    }

    private suspend fun checkForNewReleases() {
        try {
            val lastCheckTime = context.dataStore.getSuspend(LastNewReleaseCheckKey, 0L)
            val currentTime = System.currentTimeMillis()

            if (lastCheckTime == 0L) {
                context.dataStore.updateData { it.toMutablePreferences().apply {
                    set(LastNewReleaseCheckKey, currentTime)
                }}
                _hasNewReleases.value = false
                return
            }

            val hasNewReleases = _newReleaseAlbums.value.isNotEmpty() &&
                    (currentTime - lastCheckTime) > (24 * 60 * 60 * 1000)

            _hasNewReleases.value = hasNewReleases
        } catch (e: Exception) {
            reportException(e)
            _hasNewReleases.value = false
        }
    }

    fun markNewReleasesAsSeen() {
        viewModelScope.launch {
            try {
                context.dataStore.updateData { it.toMutablePreferences().apply {
                    set(LastNewReleaseCheckKey, System.currentTimeMillis())
                }}
                _hasNewReleases.value = false
            } catch (e: Exception) {
                reportException(e)
            }
        }
    }
}
